package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
@Bean
public CommandLineRunner run(CarRepository repository){
		return (args -> {
			insertJavaAdvocates(repository);
			System.out.println(repository.findAll());
		});

}
	private void insertJavaAdvocates(CarRepository repository) {
		repository.save(new Car(1,"Benz",2021,"Mercedes","blue",13));
		repository.save(new Car(2,"R8",2019,"Audi","white",13));
		repository.save(new Car(3,"Camry",2010,"Toyota","black",13));
		repository.save(new Car(4,"E200",2021,"Mercedes","red",13));


	}
}

